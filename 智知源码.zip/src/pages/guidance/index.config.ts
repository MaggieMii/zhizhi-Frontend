export default definePageConfig({
  navigationBarTitleText: '题目引导'
})
