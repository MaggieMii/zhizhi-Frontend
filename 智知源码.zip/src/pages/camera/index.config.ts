export default definePageConfig({
    navigationBarTitleText: '题目检索'
  })
  