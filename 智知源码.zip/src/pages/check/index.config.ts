export default definePageConfig({
  navigationBarTitleText: '作业检查'
})
