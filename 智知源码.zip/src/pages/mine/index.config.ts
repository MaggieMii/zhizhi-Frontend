export default definePageConfig({
    navigationBarTitleText: ''
  })
  