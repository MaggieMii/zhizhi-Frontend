export default definePageConfig({
  navigationBarTitleText: '智知隐私政策摘要'
})
